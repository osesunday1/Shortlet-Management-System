import AddBookingComp from "../../components/admin/AddBookingComp";



const AddBooking = () => {
  return (
    <div className="flex items-center justify-center min-h-screen">
    <div className="w-fit">
    <AddBookingComp/>
    </div>
    </div>
  );
};

export default AddBooking;