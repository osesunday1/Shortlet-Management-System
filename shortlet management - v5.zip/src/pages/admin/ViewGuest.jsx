import ViewGuestComp from "../../components/admin/ViewGuestComp";

const ViewGuest = () => {
  return (
    <div className="flex items-center justify-center min-h-screen">
    <div className="w-fit">
      <ViewGuestComp/>
      </div>
      </div>
  );
};

export default ViewGuest;