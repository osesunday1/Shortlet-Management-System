import ViewApartmentsComp from "../../components/admin/ViewApartmentsComp";


const ViewBookings = () => {
  return (
    <ViewApartmentsComp/>
  );
};

export default ViewBookings;